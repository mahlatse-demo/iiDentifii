package iiD.mobile.PageObjects;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import io.appium.java_client.remote.HideKeyboardStrategy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
    IOSDriver driver;
    public LoginPage(IOSDriver driver){
        this.driver = driver;
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    @CacheLookup
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Biometric Identity Authentication'")
    private WebElement biometricIdentifyLabel;

    @CacheLookup
    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Email'")
    private WebElement emailTextField;

    @CacheLookup
    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Password'")
    private WebElement passwordTextField;

    @CacheLookup
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Log in' AND name == 'Log in' AND type == 'XCUIElementTypeButton'")
    private WebElement loginButton;

    public void enterUserCredentials(String email, String password){
        try{
            emailTextField.sendKeys(email);
            biometricIdentifyLabel.click();//Temp for hiding keyboard, scrolling up would work also
            passwordTextField.sendKeys(password);
            biometricIdentifyLabel.click();//Temp for hiding keyboard, scrolling up would work also
        }catch (Exception e){
            System.out.println(e.getMessage());
        }

    }

    public void clickLoginButton(){
        try{
            loginButton.click();
            Thread.sleep(2000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }

    }
}
