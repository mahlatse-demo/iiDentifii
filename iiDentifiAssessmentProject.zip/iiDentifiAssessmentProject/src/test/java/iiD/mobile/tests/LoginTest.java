package iiD.mobile.tests;

import iiD.mobile.BaseTest.BaseClass;
import iiD.mobile.PageObjects.LoginPage;
import org.testng.annotations.Test;

public class LoginTest extends BaseClass {
    String email = "mahlatsemoses@gmail.com";
    String password = "12345&&990WW";
    @Test
    public void loginWithInvalidCredentials(){
       try {
           LoginPage loginPage = new LoginPage(driver);
           loginPage.enterUserCredentials(email,password);
           loginPage.clickLoginButton();
       }catch (Exception e){
           System.out.println("error occurred : " + e.getMessage());
       }
    }
}
