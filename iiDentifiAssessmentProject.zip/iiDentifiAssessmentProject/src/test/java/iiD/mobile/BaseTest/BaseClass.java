package iiD.mobile.BaseTest;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import java.net.URL;

public class BaseClass {
    public IOSDriver driver;
    @BeforeTest
    public void initialize(){
        try{
            System.out.println("initializing iOS driver");
            XCUITestOptions options = new XCUITestOptions()
                    .setDeviceName("iPhone 13 Pro Max")
                    .setPlatformName("iOS")
                    .setUdid("00008110-000621E43C20401E")
                    .setPlatformVersion("15.4.1")
                    .setBundleId("com.iidentifii.com.store")
                    .setAutoAcceptAlerts(true)
                    .setDerivedDataPath("/Users/F5580307/Library/Developer/Xcode/DerivedData/WebDriverAgent-fxmsedpwfaalxlbcwefbceeuodem");

            driver = new IOSDriver(new URL("http://127.0.0.1:4723/wd/hub"), options);
        }catch (Exception e){
            System.out.println("Initializing driver error : " + e.getMessage());
        }

    }

public IOSDriver getDriver(){
        return driver;
}
    @AfterTest
    public void tearDown(){
        System.out.println("closing the app and driver");
        if(driver != null){
            driver.quit();
            driver = null;
        }

    }
}
